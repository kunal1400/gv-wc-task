jQuery(document).ready(function() {
	jQuery("table.attributes-table").before("<div id='savingMsg'></div>")
	jQuery("table.attributes-table tbody").sortable({
		start: function(event, ui) {
			jQuery("#savingMsg").text("Saving please wait...")
		},
		stop: function(event, ui) {
			var arrayOfTermsUrl = []
			jQuery("table.attributes-table tbody tr").each(function(i) {
				// Pushing the href in array
				var json = {
					url_with_term_name: jQuery(this).find("strong a").attr("href"),
					position: i
				}
				arrayOfTermsUrl.push( json )
			})
			
			var data = {
				'action': 'update_term_meta',
				arrayOfTermsUrl
			};

			jQuery.ajax({
				url: ajaxurl,
				method: 'POST',
				data,
				success: function() {
					jQuery("#savingMsg").text("Saved")
					window.setTimeout(function() {
						jQuery("#savingMsg").text("")						
					}, 2000)				
				}
			})
	    }
	});

})