<?php
/*
Plugin Name: WC Attributes Sorting
Description: Simple plugin which add functionality to sort product attributes in admin panel
Version: .1
Author: Kunal Malviya
*/

/**
 *
 * This action is adding "Filter By Terms Count" button in admin attributes page.
 *
 * If "Filter By Terms Count" is clicked then its name will be  "Reset to Default" which will reset all filters.
 *
 */
add_action( 'woocommerce_before_add_attribute_fields', 'action_woocommerce_after_add_attribute_fields', 10, 0 );

/**
*
* This is callback function of woocommerce_before_add_attribute_fields hook
*
*/
function action_woocommerce_after_add_attribute_fields() {
	$sortByUrl = admin_url('edit.php?post_type=product&page=product_attributes');

	if( !empty($_GET['custom_sort_by']) && $_GET['custom_sort_by'] == 'terms_count' ) {
		echo '<a href="'.$sortByUrl.'" class="button button-primary resetToDefault">Reset to Default</a>';
	} else {
		echo '<a href="'.$sortByUrl.'&custom_sort_by=terms_count" class="button button-primary">Filter By Terms Count</a>';
	}
}


/**
 *
 * This is the filter which show the list of all attributes in WC.
 *
 */
add_filter( 'woocommerce_attribute_taxonomies', 'filter_woocommerce_attribute_taxonomies', 10, 1 );

/**
 *
 * This is callback function of woocommerce_attribute_taxonomies
 *
 * If in URL custom_sort_by is set then it show the list order by number of terms else it show the list which was rearraged by drag and drop.
 *
 */
function filter_woocommerce_attribute_taxonomies( $array ) {
    // make filter magic happen here... 
	if ( count($array) > 0 ) {
		$sortedArray = array();
		foreach ($array as $i => $tax) {
			$attributeName = wc_attribute_taxonomy_name( $tax->attribute_name );

			// Setting count of number of terms
			$termsCount = check_taxonomy_in_db($attributeName);
			$tax->terms_count = $termsCount;

			// Setting sort Order 
			$optionName = $attributeName.'_sort_order';
			$sortPosition = get_option($optionName);
			$tax->sort_position = $sortPosition ? $sortPosition : 0;

			$sortedArray[$i] = $tax;
		}

		// If custom_sort_by is set in url
		if( !empty($_GET['custom_sort_by']) && $_GET['custom_sort_by'] == 'terms_count' ) {
			usort($sortedArray, "sort_by_terms_count");		
		} else {
			usort($sortedArray, "sort_by_postion");			
		}
    	return $sortedArray;
	}
	else {
    	return $array; 
	}
}; 


/**
 *
 * Adding some small custom CSS/JS for admin panel to work drag and drop functionality
 *
 */
add_action('admin_enqueue_scripts', 'admin_custom_js' );

/**
 *
 * Callback function of admin_enqueue_scripts
 *
 */
function admin_custom_js() { 
	wp_enqueue_style( 'attributes-sorting-css', plugins_url('/attributes-sorting/attributes-sorting.css', __FILE__ ) );
	wp_enqueue_script( 'attributes-sorting', plugins_url('/attributes-sorting/attributes-sorting.js', __FILE__ ), array ( 'jquery' ), 1.1, true );
}

/**
 *
 * Handing ajax request after user rearranged the attributes
 *
 */
add_action( 'wp_ajax_update_term_meta', 'update_term_meta_callback' );

/**
 *
 * Callback function of wp_ajax_update_term_meta
 *
 */
function update_term_meta_callback() {

	// If parameters are set from url
	if( !empty($_REQUEST['arrayOfTermsUrl']) && count($_REQUEST['arrayOfTermsUrl']) > 0 ) {

		foreach ($_REQUEST['arrayOfTermsUrl'] as $key => $data) {
			$position = $data['position'] ? $data['position'] + 1 : 1;
			$parts = parse_url( $data['url_with_term_name'] );
	    	parse_str($parts['query'], $query);

	    	// If taxonomy is set then updating taxonomy order in db
	    	if( $query['taxonomy'] ) {
	    		$optionName = $query['taxonomy'].'_sort_order';
	    		update_option($optionName, $position);
	    		echo "$optionName updated with $position \n";
	    	}
		}
	}
	wp_die();
}

/**
 *
 * This function is to check existance of taxonomy in db. I used is_taxonomy() function but it was always returning false so I made this function
 *
 */
function check_taxonomy_in_db( $taxonomy ) {
    global $wpdb;
	// return "SELECT * FROM {$wpdb->prefix}term_taxonomy WHERE taxonomy = '$taxonomy'";
	return $wpdb->get_var("SELECT count(term_id) as count FROM {$wpdb->prefix}term_taxonomy WHERE taxonomy = '$taxonomy'");
}

/**
 *
 * This is the usort callback function and it sorts by terms_count in descending order
 *
 */
function sort_by_terms_count($a, $b) {
    return $a->terms_count < $b->terms_count;
}

/**
 *
 * This is the usort callback function and it sorts by sort_position i.e the position which user set by drag and drop
 *
 */
function sort_by_postion($a, $b) {
    return $a->sort_position > $b->sort_position;
}